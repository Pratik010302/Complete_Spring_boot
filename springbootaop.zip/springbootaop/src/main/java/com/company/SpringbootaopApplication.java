package com.company;

import com.company.service.BusinessClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication
@EnableAspectJAutoProxy // this annotation is used to enable aop related annotations
public class SpringbootaopApplication implements CommandLineRunner {

	@Autowired
	BusinessClass service;

	public static void main(String[] args) {
		SpringApplication.run(SpringbootaopApplication.class, args);

	}

	@Override
	public void run(String... args) throws Exception {
		service.businessMethod();
	}
}
