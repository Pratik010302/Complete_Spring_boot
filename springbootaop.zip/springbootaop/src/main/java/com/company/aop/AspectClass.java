package com.company.aop;


import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AspectClass {

//    @Pointcut("execution(public * com.company.service.BusinessClass.businessMethod())")
//    public void pointCutExp() {
//
//    }

//    @Before("pointCutExp()")
//    public void BeginTxn(){
//        System.out.println("Transaction started...");
//    }
//
//    @After("pointCutExp()")
//    public void sendReport(){
//        System.out.println("Transaction Report shared...");
//    }
//
//    @AfterReturning("pointCutExp()")
//    public void commitTxn(){
//        System.out.println("Transaction Commited...");
//    }
//
//    @AfterThrowing(value = "pointCutExp()", throwing = "th")
//    public void rollBackTxn(Throwable th){
//        System.out.println("Transaction Rollbacked..." + th.getMessage());
//    }

//    @Around("pointCutExp()")
//    public void aroundTest(ProceedingJoinPoint jp) {
//        System.out.println("Transaction support initiated");
//        try {
//
//            jp.proceed(); // Proceed with the target method execution
//            System.out.println("Transaction committed...");
//        } catch (Throwable t) {
//            System.out.println("Transaction rolled back due to: " + t.getMessage());
//        }
//        System.out.println("Report generated....");
//
//    }

}
