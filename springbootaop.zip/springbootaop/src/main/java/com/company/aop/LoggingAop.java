package com.company.aop;

import org.aspectj.lang.annotation.*;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAop {

    public static org.slf4j.Logger logger= LoggerFactory.getLogger(LoggingAop.class);


    @Pointcut("execution(public * com.company.service.BusinessClass.businessMethod())")
    public void pointCutExp3() {

    }

    @Before("pointCutExp3()")
    public void BeginTxn(){
        //System.out.println("Transaction started...");
        logger.info("Transaction support started...");
    }

    @After("pointCutExp3()")
    public void sendReport(){
       // System.out.println("Transaction Report shared...");
        logger.info("Transaction commited....");
    }

    @AfterReturning("pointCutExp3()")
    public void commitTxn(){
//        System.out.println("Transaction Commited...");
        logger.info("Transaction commited...");
    }

    @AfterThrowing(value = "pointCutExp3()", throwing = "th")
    public void rollBackTxn(Throwable th){
        logger.error("Transaction Rolled back" + th.getMessage());
    }
}
