package com.company.service;


import org.springframework.stereotype.Service;

@Service
public class BusinessClass {

    public void businessMethod(){
        System.out.println("Business method executed...");
        System.out.println(10/2);
    }
}
