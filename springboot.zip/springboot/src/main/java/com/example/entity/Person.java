package com.example.entity;


import org.springframework.stereotype.Component;

@Component
public class Person {

    private String name = "Pratik";
    private int id = 101;

    public Person(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public Person(){
        super();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", id=" + id +
                '}';
    }
}
