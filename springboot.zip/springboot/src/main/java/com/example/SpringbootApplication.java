package com.example;

import com.example.entity.Person;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootApplication.class, args);
		System.out.println("Hello");

		Person p = new Person();
		System.out.println(p.getId());
		System.out.println(p.getName());
	}

}
