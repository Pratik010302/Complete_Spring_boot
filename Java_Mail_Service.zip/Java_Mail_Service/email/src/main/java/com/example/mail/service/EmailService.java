package com.example.mail.service;

import org.springframework.stereotype.Service;
import javax.mail.*;
import javax.mail.internet.*;
import java.io.File;
import java.util.Properties;

@Service
public class EmailService {

    private final String senderEmail = "pratikwaghpw888@gmail.com"; // Replace with your email
    private final String senderPassword = "reko kdse ypdy ltyc";     // Replace with your password or App Password

    public void sendEmail(String recipient, String subject, String body, String attachmentPath) throws Exception {
        // SMTP Configuration
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");

        // Session Authentication
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        // Create Email Message
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(senderEmail));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
        message.setSubject(subject);

        // Create Email Body
        Multipart multipart = new MimeMultipart();

        // Text Part
        MimeBodyPart textPart = new MimeBodyPart();
        textPart.setText(body);
        multipart.addBodyPart(textPart);

        // Attachment Part (Optional)
        if (attachmentPath != null && !attachmentPath.isEmpty()) {
            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.attachFile(new File(attachmentPath));
            multipart.addBodyPart(attachmentPart);
        }

        // Set Content
        message.setContent(multipart);

        // Send Email
        Transport.send(message);
        System.out.println("Email sent successfully to: " + recipient);
    }
}
