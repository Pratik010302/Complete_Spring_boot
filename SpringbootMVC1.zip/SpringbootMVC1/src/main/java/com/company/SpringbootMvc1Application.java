package com.company;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMvc1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMvc1Application.class, args);
		System.out.println("Hello");
	}

}
