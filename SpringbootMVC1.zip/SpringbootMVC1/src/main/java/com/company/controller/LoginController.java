package com.company.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {
	@GetMapping("/authenticate")
	public String AuthenticateUser(@RequestParam("username") String username,
			@RequestParam("password")String password) {
		if(username.equalsIgnoreCase("coforge") && password.equalsIgnoreCase("coforge@123")) {
			return "redirect:/home.html";
		}
	    return "redirect:/error.html";
		 
	}

}

