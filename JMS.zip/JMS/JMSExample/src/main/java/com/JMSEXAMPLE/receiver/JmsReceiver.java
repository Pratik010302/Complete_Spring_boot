package com.JMSEXAMPLE.receiver;


import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class JmsReceiver {

    @JmsListener(destination = "testingmessage")
    public void receiveMessage(String message){

        System.out.println("JMS Message Received using JMS Service" + message );
    }
}
