package com.JMSEXAMPLE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JmsExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
