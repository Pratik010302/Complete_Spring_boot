package com.example.springrest.services;

import com.example.springrest.dao.CourseDao;
import com.example.springrest.entities.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseServiceImpl implements CourseService{

    @Autowired
    private CourseDao courseDao;

    //List<Course> list = new ArrayList<>();
    public CourseServiceImpl(){
//        list.add(new Course(111,"Java Course","This is best java course"));
//        list.add(new Course(222,"Spring Boot","this is best spring boot course"));
    }
    @Override
    public List<Course> getCourses() {
        return courseDao.findAll();
    }

    @Override
    public Optional<Course> getCourse(long courseId) {
//

        return courseDao.findById(courseId);
    }

    @Override
    public Course addCourse(Course course) {
        //Course c = null;
//        for(Course course:list){
//            if(course.getId() == courseId){
//                c = course;
//                break;
//            }
//        }
//        list.add(course);

        courseDao.save(course);
        return course;
    }

    @Override
    public Course updateCourse(Course course) {
//        list.forEach(e->{
//            if (e.getId() == course.getId()) {
//
//                e.setTitle(course.getTitle());
//                e.setDescription(course.getDescription());
//            }
//        });
        courseDao.save(course);
        return course;
    }

    @Override
    public void deleteCourse(long courseId) {
      //list = this.list.stream().filter(e->e.getId() != courseId).collect(Collectors.toList());

        Course entity = courseDao.getOne(courseId);
        courseDao.delete(entity);
    }
}
