package com.company.controller;


import com.company.entities.Customer;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("customer")
public class customerController {

    private List<Customer> list = createlist();

    @PostMapping("/add")
    public String addCustomer(){

        return "customer added";
    }

    @GetMapping(value = "/getdetails",produces = "application/json")
    public List<Customer>  viewAllCustomers(){
        return list;
    }

    @DeleteMapping("/delete")
    public String  deleteCustomer(){
        return "customer deleted...";
    }

    @PutMapping("/update")
    public String updateCustomer(){
        return "customer details updated...";
    }

    public static List<Customer> createlist(){
        List<Customer> temp = new ArrayList<>();
        Customer c1 = new Customer(101,"Pratik");
        Customer c2 = new Customer(102,"Rakesh");

        temp.add(c1);
        temp.add(c2);

        return temp;
    }

}
