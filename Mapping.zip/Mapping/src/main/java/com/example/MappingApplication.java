package com.example;

import com.example.entities.Passport;
import com.example.entities.Person;
import com.example.service.PassportService;
import com.example.service.PersonService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.Date;

@SpringBootApplication
public class MappingApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(MappingApplication.class, args);

		System.out.println("Hello");
		PersonService personService = context.getBean(PersonService.class);
		PassportService passportService = context.getBean(PassportService.class);

		Passport p = new Passport(111,"GOI",new Date(),new Date());
		passportService.add(p);
		Person p1 = new Person(7000,"Ram",30,p);
		personService.add(p1);

		Person p2 = personService.findPersonById(7000);
		if(p2 != null){
			System.out.println(p2.getSsn() + " " + p2.getName() + " " + p2.getAge());

			Passport p3 = passportService.findPassportById(111);
			if(p3 != null){
				System.out.println(p3.getPassportNo() + " " + p3.getIssueAuthority()+ " " + p3.getIssueDate() +
						" " + p3. getExpiryDate());
			}
		}

	}

}
