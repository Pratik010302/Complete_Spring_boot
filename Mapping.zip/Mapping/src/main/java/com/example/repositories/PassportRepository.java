package com.example.repositories;

import com.example.entities.Passport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

public interface PassportRepository extends CrudRepository<Passport,Integer> {
}
