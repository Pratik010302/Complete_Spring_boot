package com.example.service;


import com.example.entities.Passport;
import com.example.entities.Person;
import com.example.repositories.PassportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PassportService {

    @Autowired
    private PassportRepository passportRepository;

    public Passport findPassportById(int passportId){
        Optional<Passport> p = passportRepository.findById(passportId);

        return p.orElse(null);
    }

    public boolean add(Passport p){
        Passport p1 = passportRepository.save(p);

        return true;
    }
}
