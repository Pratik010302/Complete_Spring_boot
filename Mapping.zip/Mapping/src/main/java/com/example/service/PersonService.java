package com.example.service;


import com.example.entities.Person;
import com.example.repositories.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PersonService {

    @Autowired
    PersonRepository personRepository;

    public Person findPersonById(int ssn){
        Optional<Person> p = personRepository.findById(ssn);

        return p.orElse(null);
    }

    public boolean add(Person p){
        Person p1 = personRepository.save(p);

        return true;
    }
}
