package com.example.entities;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity

public class Person {

    @Id
    private int ssn;
    @Column(name="per_name")
    private String name;
    @Column(name = "per_age")
    private int age;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "passport_no")
    Passport passport;

    public Person(){
        super();
    }


    public Person(int ssn, String name, int age, Passport passport) {
        this.ssn = ssn;
        this.name = name;
        this.age = age;
        this.passport = passport;
    }

    public int getSsn() {
        return ssn;
    }

    public void setSsn(int ssn) {
        this.ssn = ssn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Passport getPassport() {
        return passport;
    }

    public void setPassport(Passport passport) {
        this.passport = passport;
    }
}
