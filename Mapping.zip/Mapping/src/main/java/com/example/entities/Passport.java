package com.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity

@Getter
@Setter
public class Passport {

    @Id
    private int passportNo;
    @Column(name = "issue_auth")
    private String issueAuthority;
    @Column(name="issue_date")
    private Date issueDate;
    @Column(name = "exp_date")
    private Date expiryDate;

    public Passport(){
        super();
    }

    public Passport(int passportNo, String issueAuthority, Date issueDate, Date expiryDate) {
        this.passportNo = passportNo;
        this.issueAuthority = issueAuthority;
        this.issueDate = issueDate;
        this.expiryDate = expiryDate;
    }

    public int getPassportNo() {
        return passportNo;
    }

    public void setPassportNo(int passportNo) {
        this.passportNo = passportNo;
    }

    public String getIssueAuthority() {
        return issueAuthority;
    }

    public void setIssueAuthority(String issueAuthority) {
        this.issueAuthority = issueAuthority;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }
}
